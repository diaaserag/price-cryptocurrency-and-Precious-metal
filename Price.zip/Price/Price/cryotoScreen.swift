//
//  cryotoScreen.swift
//  Price
//
//  Created by diaa on 17/08/2021.
//

import UIKit
import Alamofire
import SwiftyJSON
class cryotoScreen: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
       let arrname = ["BTC","BNB","ETH"]
    var url = "https://min-api.cryptocompare.com/data/price?fsym="
    // please make sure the api is still valid because it's free and has an expir date
    let apiKey = "ef3a1581e7efe1f2e630643f21fec0e02406420fe60e2415bdcb284d629c2e4d"
    // please make sure the api is still valid because it's free and has an expir date
    @IBOutlet weak var pickerNames: UIPickerView!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var imagDes: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerNames.delegate = self
        pickerNames.dataSource = self
    }
    


}
extension cryotoScreen{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        arrname.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrname[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let selected = arrname[row]
       var z = url + selected + "&tsyms=USD&api_key=" + apiKey
        getdata(url: z,sel: selected)
        z = ""
    }
}
extension cryotoScreen{
    func getdata(url:String,sel : String){
        Alamofire.request(url, method: .get).responseJSON{ [self]respons in
            if respons.result.isSuccess{
                // please make sure the api is still valid because it's free and has an expir date
                let price : JSON = JSON(respons.result.value!)
                // please make sure the api is still valid because it's free and has an expir date
                self.lblPrice.text = "\(price["USD"])"
                imagDes.image = UIImage(named: sel)
            }
        }
    }
}
