//
//  fiatScreen.swift
//  Price
//
//  Created by diaa on 17/08/2021.
//

import UIKit

class fiatScreen: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


}
