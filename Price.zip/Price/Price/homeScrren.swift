//
//  ViewController.swift
//  Price
//
//  Created by diaa on 17/08/2021.
//

import UIKit

class homeScrren: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonHomeScreen(_ sender: UIButton) {
        if sender.tag == 1{
            let goto = self.storyboard?.instantiateViewController(withIdentifier: "metal")as? metallsScereen
            present(goto!, animated: true, completion: nil)
        }
        else if sender.tag == 2{
            let goto = self.storyboard?.instantiateViewController(withIdentifier: "crypto")as? cryotoScreen
            present(goto!, animated: true, completion: nil)
        }
    }
    
}

