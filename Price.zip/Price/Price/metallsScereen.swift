//
//  metallsScereen.swift
//  Price
//
//  Created by diaa on 17/08/2021.
//

import UIKit
import Alamofire
import SwiftyJSON
class metallsScereen: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    // please make sure the api is still valid because it's free and has an expir date
    let apiKey = "dj8vgcmyk1gre6gsf2cq8e7xo8xr6rmf7zs523cpumohhw89hfy8hn62c1v2"
    // please make sure the api is still valid because it's free and has an expir date
    var Url = "https://metals-api.com/api/latest?"
    let arrsempol =  ["XAU","XAG","XPD"]
    let arrmetal = ["Gold","Silver","Platinum"]
    @IBOutlet weak var bickerForMetalls: UIPickerView!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var imagDescripation: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        bickerForMetalls.delegate = self
        bickerForMetalls.dataSource = self
    }
}
extension metallsScereen{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrmetal.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrmetal[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let x = arrsempol[row]
        let paras : [String:String] = ["access_key":apiKey,"&base":"USD","symbols":arrsempol[row]]
          getData(url: Url, para: paras, x: x)
    }
}

extension metallsScereen{
    func getData(url:String,para:[String:String],x:String){
        Alamofire.request(url, method: .get, parameters: para).responseJSON{ [self]respons in
            if respons.result.isSuccess {
                let pricemetal : JSON = JSON(respons.result.value!)
                if pricemetal.isEmpty {
                // please make sure the api is still valid because it's free and has an expir date
                let priceend = (1 / pricemetal["rates"][x].double! )
                lblPrice.text = "\(String(format: "%.2f", priceend))"
                imagDescripation.image = UIImage(named: x)
            }
                else{
                    print("please make sure the api is still valid because it's free and has an expir date")
                    print("you can go and use your api and your key ")
                }
            }
        }
    }
}
